# movielens-data-analysis

Data Analysis of Movielens 1M Dataset

**To run this code locally:**

1. Fork this repository
2. Clone it using `git clone (repository link)`
3. Open the `.ipynb` file using Jupyter Notebook or any other IDE like PyCharm, VS Code etc.

Feel free to suggest any kind of improvement.
